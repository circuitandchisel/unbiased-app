# unbiased-iui

Versioned intelligent UI components and their agent-facing catalogue for Unbiased.

This repository owns the React implementation, input schema, interaction contract, and examples for each component. The agent sees the generated catalogue, not React source. The app bundles a pinned package version; a remote catalogue is metadata, never executable code.

## Components

The catalogue includes `GuidedExplainer` plus a curated set from OpenUI 0.17.0: `Stack`, `TextContent`, `Callout`, `Steps`, `StepsItem`, `Table`, `Col`, `BarChart`, `LineChart`, `Series`, and `Separator`. These are imported from `@openuidev/react-ui`, not copied. Their OpenUI definitions drive both the runtime library and the generated catalogue. A new upstream version must be deliberately pinned, tested, and regenerated.

The first set focuses on explanations and read-only data. General-purpose `Card` and `Tabs` currently expand into very large schemas, and input/action components need a host action policy, so they are not yet in the agent-facing catalogue.

### Guided explainer

`GuidedExplainer` presents a 2-12 step narrative with selectable steps, imagery, a concise explanation, and Back/Next controls. It is intended for stories, journeys, and processes, not general-purpose charts or graphs. Generated data can only name image asset IDs. The host must resolve IDs through `IUIAssetProvider`; raw model-supplied URLs never become network requests.

```tsx
import { GuidedExplainer, IUIAssetProvider } from "@unbiased/iui";
import "@unbiased/iui/styles.css";

<IUIAssetProvider resolveAsset={(id) => approvedAssets[id]}>
  <GuidedExplainer title="A journey" steps={steps} />
</IUIAssetProvider>
```

`@unbiased/iui/openui` exports an OpenUI `defineComponent` adapter and a curated library for OpenUI Lang. `Stack` is its root so components can be combined. The base React component and Zod schema do not depend on OpenUI's renderer. To render OpenUI Lang, wrap the host `Renderer` in `.iui-openui` and import `@unbiased/iui/openui-styles.css`; the stylesheet imports OpenUI's upstream styles and scopes Unbiased's dark tokens to that wrapper. The desktop app bundles this library, registers its own sandboxed visual components alongside it, and uses one OpenUI renderer for visual responses.

## Catalogue contract

`src/openui-standard.ts` selects the upstream definitions and records component guidance. `src/catalogue.ts` adds the local component. `catalogue/components.json` and `catalogue/openui-spec.json` are generated from those sources. The app currently gives the agent all component signatures and descriptions from the bundled spec. A chart or table needs its dependent `Series` or `Col` definition too.

```sh
npm install
npm run catalogue:build
npm run verify
npm run dev
```

The gallery runs at `http://127.0.0.1:4173`. `catalogue:verify` fails if the committed JSON differs from the source. A future remotely fetched catalogue should be signed and last-good cached, following the connectors catalogue pattern; this first version is bundled and does not claim remote-update trust.

The gallery uses three Unsplash photographs only as demo assets: [open sea](https://unsplash.com/photos/a-sailboat-in-the-ocean-at-sunset-bAHMC9W2Di4), [cave](https://unsplash.com/photos/a-man-standing-in-a-cave-looking-out-at-the-water-n6PKibMAnsw), and [coast](https://unsplash.com/s/photos/mediterranean-sea). These URLs are host-owned demo data, not generated component input.

## Upstream reuse

The OpenUI adapter depends on `@openuidev/react-lang` and `@openuidev/react-ui` rather than copying their code. OpenUI is MIT-licensed; retain its copyright and license notice if its source is ever copied into this repository. Components copied from any other project need their own license review and attribution.
